require "libs.all"

require "prototypes.fat-boiler"
require "prototypes.rotary-motion-engine"