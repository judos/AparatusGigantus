
modVersion = "0.0.1" --version of control data, only updated when control.lua changes
modName = "AparatusGigantus" -- required prefix for all ui name components which can be clicked
fullModName = "AparatusGigantus" -- required for logging and prototypes


libLog.debug_master = true
--libLog.testing = true
--libLog.testing = false -- enables player printing of every log, sets log level to info
--libLog.debug_level = 1  -- 1=info 2=warn 3=error